There are two sets of instances in this folder.

The first set consists of instances generated using the CUTGEN1 generator, located in the folder "Cutgen". This folder contains 1800 instances, each named in the format Ci-j-Ck, where:

- i indicates the class number,
- j identifies the instance number within that class, and
- k is the maximum number of open stacks allowed.

Each instance follows the format:

C=k        (with k ranging from 2 to 4, depending on the maximum number of open stacks allowed)
M
L
l
d

Where:
- k is the maximum number of open stacks allowed
- M is the number of distinct item types
- L is the length of the large object
- l is a vector containing the lengths of each item type
- d is a vector containing the demand for each item type

For example, the first instance of Class 1 with C=2 (C1-1-C2) is:

C=2
10
1000
[164, 158, 139, 135, 125, 114, 108, 74, 64, 12]
[13, 13, 17, 17, 11, 4, 5, 6, 10, 4]

The second set corresponds to the Fiber instances, located in the folder "Fiber". This folder contains 6 .txt files, each with 20 instances.

- The file named "Fiber_5180" contains instances with object length equal to 5180.
- The file named "Fiber_9080" contains instances with object length equal to 9080.

The prefix Ck in front of each file name indicates the maximum number of open stacks allowed.

All instances in these files follow the same format as the CUTGEN1 instances and are separated by line breaks.
